/*
*	DKU Operating System Lab
*	    Lab1 (Scheduler Algorithm Simulator)
*	    Student id : 32183698
*	    Student name : Lee Hyungi
*
*   lab1_sched.c :
*       - Lab1 source file.
*       - Must contains scueduler algorithm test code.
*
*/

#include <aio.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <pthread.h>
#include <asm/unistd.h>

#include "lab1_sched_types.h"

/*
 * you need to implement scheduler simlator test code.
 *
 */

int main(int argc, char *argv[]){

	if(argc!=2) {
		printf("Usage: %s number", argv[0]);
		exit(-1);
	}

	queue Q;
	init(&Q);

	printf("First workload \n");

	process P[5];
	P[0].p_name = "A";
	P[0].arr_t = 0;
	P[0].run_t = 3;

	P[1].p_name = "B";
	P[1].arr_t = 2;
	P[1].run_t = 6;

	P[2].p_name = "C";
	P[2].arr_t = 4;
	P[2].run_t = 4;

	P[3].p_name = "D";
	P[3].arr_t = 6;
	P[3].run_t = 5;
	
	P[4].p_name = "E";
	P[4].arr_t = 8;
	P[4].run_t = 2;

	FCFS(P, 5);

	RR(P, 5);

	SPN(P, 5);

	printf("Second workload\n");

	process Pr[5];

	Pr[0].p_name = "1";
        Pr[0].arr_t = 0;
        Pr[0].run_t = 2;

        Pr[1].p_name = "2";
        Pr[1].arr_t = 2;
        Pr[1].run_t = 3;

        Pr[2].p_name = "3";
        Pr[2].arr_t = 3;
        Pr[2].run_t = 5;

        Pr[3].p_name = "4";
        Pr[3].arr_t = 5;
        Pr[3].run_t = 4;

        Pr[4].p_name = "5";
        Pr[4].arr_t = 7;
        Pr[4].run_t = 6;

	FCFS(Pr, 5);

	RR(Pr, 5);

	SPN(Pr, 5);

}

