/*
*	DKU Operating System Lab
*	    Lab1 (Scheduler Algorithm Simulator)
*	    Student id : 32183698
*	    Student name : Lee Hyungi
*
*   lab1_sched_types.h :
*       - lab1 header file.
*       - must contains scueduler algorithm function's declations.
*
*/

#ifndef _LAB1_HEADER_H
#define _LAB1_HEADER_H

#define MAX 5
typedef struct{
        char* p_name;
        int arr_t;
        int run_t;
} process;

typedef struct{
	int front, rear;
	char name[MAX];
} queue;

void init(queue* Q);
int isfull(queue* Q);
int isempty(queue* Q);
void enqueue(queue* Q, char a);
char dequeue(queue* Q);

void FCFS(process* pro, int n);
void RR(process* pro, int n);
void SPN(process* pro, int n);
void HRRN();
void FB1();
void FB2();

/*
 * You need to Declare functions in  here
 */


#endif /* LAB1_HEADER_H*/



