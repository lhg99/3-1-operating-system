/*
*	DKU Operating System Lab
*	    Lab1 (Scheduler Algorithm Simulator)
*	    Student id : 32183698
*	    Student name : Lee Hyungi
*
*   lab1_sched.c :
*       - Lab1 source file.
*       - Must contains scueduler algorithm function'definition.
*
*/

#include <aio.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <pthread.h>
#include <asm/unistd.h>

#include "lab1_sched_types.h"

/*
 * you need to implement FCFS, RR, SPN, HRRN, MLFQ scheduler.
 */

void init(queue* Q) {
	Q->front = -1;
	Q->rear = -1;
}

int isfull(queue* Q) {
	return Q->rear == MAX-1;
}

int isempty(queue* Q) {
	return Q->rear == Q->front;
}

void enqueue(queue* Q, char a) {
	if(isfull(Q)) {
		printf("Queue is full\n");
		exit(-1);
	}
	Q->name[++Q->rear] = a;
}

char dequeue(queue* Q) {
	if(isempty(Q)) {
		printf("Queue is empty\n");
		exit(-1);
	}
	return Q->name[++Q->front];

}

void FCFS(process* pro, int n) {
	int temp = 0;
	int i;
	printf("FCFS \n");
	for(i=0;i<n;i++) {
		if(pro[i].arr_t < pro[i+1].arr_t){
			temp = temp + pro[i].run_t;
		}
		printf("Process: %s end_t: %d \n", pro[i].p_name, temp);
	}
}

void RR(process* pro, int n) {
	int quantum = 1;
	int temp = 0;
	int i;
	printf("RR \n");
	for(i=0;i<n;i++) {
		if(pro[i].arr_t < pro[i+1].arr_t) {
			if(pro[i].run_t > quantum) {
				temp = pro[i].run_t - quantum;
				printf("Process : %s end_t : %d \n",
					       	pro[i].p_name, temp);
			}
		}
	}
}

void SPN(process* pro, int n) {
	int temp = 0;
	int i;
	printf("SPN \n");
	for(i=0;i<n;i++) {
		if(pro[i].arr_t < pro[i+1].arr_t) {
			temp = temp + pro[i].run_t;
		}
		if(pro[i].run_t < pro[i].run_t) {
			temp = temp + pro[i].run_t;
		}
		printf("Process: %s, end_t: %d \n", pro[i].p_name, temp);
	}
}

void HRRN(process* pro, int n) {
	
}

void FB1() {

}

void FB2() {

}
