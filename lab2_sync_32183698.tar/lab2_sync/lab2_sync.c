/*
*   DKU Operating System Lab
*           Lab2 (Hash Queue Lock Problem)
*           Student id : 32183698
*           Student name : Lee Hyungi
*
*   lab2_sync.c :
*       - lab2 main file.
*		- Thread-safe Hash Queue Lock code
*		- Coarse-grained, fine-grained lock code
*       - Must contains Hash Queue Problem function's declations.
*
*   Implement thread-safe Hash Queue for coarse-grained verison and fine-grained version.
*/

#include <aio.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <pthread.h>
#include <asm/unistd.h>

#include "lab2_sync_types.h"

pthread_mutex_t mutex_q_cg, mutex_q_fg, mutex_h_cg, mutex_h_fg;

/*
 * TODO
 *  Implement function which init queue nodes for front and rear
 *  ( refer to the ./include/lab2_sync_types.h for front and rear nodes)
 */
void init_queue() {
	front = (queue_node*)malloc(sizeof(queue_node));
	rear = (queue_node*)malloc(sizeof(queue_node));
	front->prev = front;
	front->next = rear;
	rear->prev = front;
	rear->next = rear;
	pthread_mutex_init(&mutex_q_cg, NULL);
	pthread_mutex_init(&mutex_q_fg, NULL);
}

/*
 * TODO
 *  Implement function which add new_node at next rear node
 *
 *  @param queue_node *new_node		: Node which you need to insert at queue.
 */
void enqueue(queue_node *new_node) {
	queue_node *tmp = malloc(sizeof(queue_node));
	tmp->data = new_node->data;
	tmp->next = NULL;

	if(front == NULL) {
		front = tmp;
	}
	else {
		rear->next = tmp;
	}
	rear = tmp;
}

/*
 * TODO
 *  Implement function which add new_node at next rear node
 *
 *  @param queue_node *new_node		: Node which you need to insert at queue in coarse-grained manner.
 */
void enqueue_cg(queue_node *new_node) {
	pthread_mutex_lock(&mutex_q_cg);
	queue_node *tmp = malloc(sizeof(queue_node));
        tmp->data = new_node->data;
        tmp->next = NULL;

        if(front == NULL) {
                front = tmp;
        }
        else {
                rear->next = tmp;
        }
        rear = tmp;
	pthread_mutex_unlock(&mutex_q_cg);
}

/*
 * TODO
 *  Implement function which add new_node at next rear node
 *
 *  @param queue_node *new_node		: Node which you need to insert at queue in fine-grained manner.
 */
void enqueue_fg(queue_node *new_node) {
	pthread_mutex_lock(&mutex_q_fg);
	queue_node *tmp = malloc(sizeof(queue_node));
        tmp->data = new_node->data;
        tmp->next = NULL;
	pthread_mutex_unlock(&mutex_q_fg);

	pthread_mutex_lock(&mutex_q_fg);
        if(front == NULL) {
                front = tmp;
        }
        else {
                rear->next = tmp;
        }
        rear = tmp;
	pthread_mutex_unlock(&mutex_q_fg);
}
/*
 * TODO
 *  Implement function which delete del_node at location that contains target key
 *
 *  @param queue_node *del_node		: Node which you need to delete at queue.
 */
void dequeue(queue_node *del_node) {
	queue_node* tmp;
	if(del_node == NULL) {
		free(del_node);
	}
	tmp = front;
	front = tmp->next;
	free(tmp);
}

/*
 * TODO
 *  Implement function which delete del_node at location that contains target key
 *
 *  @param queue_node *del_node		: Node which you need to delete at queue in coarse-grained manner.
 */
void dequeue_cg(queue_node *del_node) {
	pthread_mutex_lock(&mutex_q_cg);
	queue_node* tmp;
        if(del_node == NULL) {
                free(del_node);
        }
        tmp = front;
        front = tmp->next;
        free(tmp);
	pthread_mutex_unlock(&mutex_q_cg);
}

/*
 * TODO
 *  Implement function which delete del_node at location that contains target key
 *
 *  @param queue_node *del_node		: Node which you need to delete at queue in fine-grained manner.
 */
void dequeue_fg(queue_node *del_node) {
	pthread_mutex_lock(&mutex_q_fg);
	queue_node* tmp;
        if(del_node == NULL) {
                free(del_node);
        }
        tmp = front;
        front = tmp->next;
        free(tmp);
	pthread_mutex_unlock(&mutex_q_fg);
}

/*
 * TODO
 *  Implement function which init hashlist(same as hashtable) node.
 */
void init_hlist_node() {
	int i;
        for(i=0;i<HASH_SIZE;i++) {
                hlist_node *h_list = hashlist[i];
		hlist_node *tmp;
		while(h_list !=NULL) {
			tmp = h_list;
			h_list = h_list->next;
			h_list->q_loc = NULL;
			free(tmp);
		}
		hashlist[i] = NULL;
        }
	pthread_mutex_init(&mutex_h_cg, NULL);
	pthread_mutex_init(&mutex_h_fg, NULL);
}

/*
 * TODO
 *  Implement function which calculate hash value with modulo operation.
 */
int hash(int val) {
	int key;
	key = val % HASH_SIZE;
	return key;
}

/*
 * TODO
 *  Implement function which insert the resilt of finding the location 
 *  of the bucket using value to the entry and hashtable
 *
 *  @param hlist_node *hashtable		: A pointer variable containing the bucket
 *  @param int val						: Data to be stored in the queue node
 */
void hash_queue_add(hlist_node *hashtable, int val) {
	assert(hashtable != NULL);
	queue_node *tmp = malloc(sizeof(queue_node));
	tmp->data = val;
	enqueue(tmp);
}

/*
 * TODO
 *  Implement function which insert the resilt of finding the location 
 *  of the bucket using value to the entry and hashtable
 *
 *  @param hlist_node *hashtable		: A pointer variable containing the bucket
 *  @param int val						: Data to be stored in the queue node
 */
void hash_queue_add_cg(hlist_node *hashtable, int val) {
	assert(hashtable != NULL);
        queue_node *tmp = malloc(sizeof(queue_node));
        tmp->data = val;
        enqueue(tmp);
}

/*
 * TODO
 *  Implement function which insert the resilt of finding the location 
 *  of the bucket using value to the entry and hashtable
 *
 *  @param hlist_node *hashtable		: A pointer variable containing the bucket
 *  @param int val						: Data to be stored in the queue node
 */
void hash_queue_add_fg(hlist_node *hashtable, int val) {
	assert(hashtable != NULL);
	pthread_mutex_lock(&mutex_h_fg);
        queue_node *tmp = malloc(sizeof(queue_node));
        tmp->data = val;
        enqueue(tmp);
	pthread_mutex_unlock(&mutex_h_fg);
}

/*
 * TODO
 *  Implement function which check if the data(value) to be stored is in the hashtable
 *
 *  @param int val						: variable needed to check if data exists
 *  @return								: status (success or fail)
 */
int value_exist(int val) {
	int key = hash(val);
	if(hashlist[key] == NULL)
		return 0;
	else
		return 1;
}

/*
 * TODO
 *  Implement function which find the bucket location using target
 */
void hash_queue_insert_by_target() {
	int a = value_exist(target);
	if(a == 1) {
		hash_queue_add(hashlist[hash(target)], target);
	}
}

/*
 * TODO
 *  Implement function which find the bucket location using target
 */
void hash_queue_insert_by_target_cg() {
	int a = value_exist(target);
        if(a == 1) {
                hash_queue_add_cg(hashlist[hash(target)], target);
        }

}

/*
 * TODO
 *  Implement function which find the bucket location using target
 */
void hash_queue_insert_by_target_fg() {
	int a = value_exist(target);
        if(a == 1) {
                hash_queue_add_fg(hashlist[hash(target)], target);
        }

}

/*
 * TODO
 *  Implement function which find the bucket location and stored data
 *  using target and delete node that contains target
 */
void hash_queue_delete_by_target() {
	int b = value_exist(target);
	if(b == 1)
		dequeue(hashlist[hash(target)]->q_loc);
}

/*
 * TODO
 *  Implement function which find the bucket location and stored data
 *  using target and delete node that contains target
 */
void hash_queue_delete_by_target_cg() {
	int b = value_exist(target);
        if(b == 1)
                dequeue_cg(hashlist[hash(target)]->q_loc);
}

/*
 * TODO
 *  Implement function which find the bucket location and stored data
 *  using target and delete node that contains target
 */
void hash_queue_delete_by_target_fg() {
	int b = value_exist(target);
        if(b == 1)
                dequeue_fg(hashlist[hash(target)]->q_loc);
}

